import { Link, useNavigate } from "react-router";
import { Shield, Truck, RefreshCcw, CheckCircle, ShoppingCart, ArrowLeft } from "lucide-react";
import { ImageWithFallback } from "../../components/figma/ImageWithFallback";
import { useState } from "react";

export default function ProductPage() {
  const navigate = useNavigate();
  const [quantity, setQuantity] = useState(1);

  const product = {
    id: 1,
    name: "Handmade Silver Necklace",
    price: 2499,
    description: "Beautiful handcrafted silver necklace with intricate design. Made with 92.5% pure silver. Perfect for everyday wear or special occasions.",
    images: [
      "https://images.unsplash.com/photo-1606760227091-3dd870d97f1d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYW5kbWFkZSUyMGpld2VscnklMjBhY2Nlc3Nvcmllc3xlbnwxfHx8fDE3ODE1MzMwNzJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    ],
    seller: {
      name: "Artisan Jewelry Co.",
      verified: true,
      rating: 4.8,
      totalSales: 1240,
    },
    deliveryTime: "3-5 days",
  };

  const trustFeatures = [
    {
      icon: Shield,
      title: "Payment Protected",
      description: "Money held until delivery",
    },
    {
      icon: Truck,
      title: "Fast Delivery",
      description: "3-5 business days",
    },
    {
      icon: RefreshCcw,
      title: "Easy Returns",
      description: "7 days return policy",
    },
    {
      icon: CheckCircle,
      title: "Verified Seller",
      description: "KYC approved",
    },
  ];

  const handleAddToCart = () => {
    navigate("/cart");
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="border-b bg-white sticky top-0 z-10">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-r from-purple-600 to-pink-600">
                <span className="text-white font-bold">L</span>
              </div>
              <span className="text-xl font-bold text-gray-900">Loopy</span>
            </Link>
            <Link
              to="/cart"
              className="flex items-center gap-2 rounded-lg border border-gray-300 bg-white px-4 py-2 text-sm text-gray-900 hover:bg-gray-50"
            >
              <ShoppingCart className="h-4 w-4" />
              Cart
            </Link>
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        {/* Back Button */}
        <button
          onClick={() => navigate(-1)}
          className="mb-6 flex items-center gap-2 text-sm text-gray-600 hover:text-gray-900"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to products
        </button>

        <div className="grid gap-8 lg:grid-cols-2">
          {/* Product Images */}
          <div>
            <div className="overflow-hidden rounded-xl bg-white shadow-sm">
              <div className="aspect-square bg-gray-100">
                <ImageWithFallback
                  src={product.images[0]}
                  alt={product.name}
                  className="h-full w-full object-cover"
                />
              </div>
            </div>
          </div>

          {/* Product Info */}
          <div>
            <div className="rounded-xl bg-white p-6 shadow-sm">
              {/* Verified Badge */}
              <div className="mb-4 inline-flex items-center gap-2 rounded-full bg-green-50 px-3 py-1 text-sm text-green-700">
                <CheckCircle className="h-4 w-4" />
                Verified Seller
              </div>

              <h1 className="text-3xl font-bold text-gray-900">
                {product.name}
              </h1>

              <div className="mt-2 flex items-baseline gap-2">
                <span className="text-3xl font-bold text-gray-900">
                  ₹{product.price.toLocaleString()}
                </span>
              </div>

              {/* Seller Info */}
              <div className="mt-4 flex items-center gap-2 text-sm text-gray-600">
                <span>Sold by</span>
                <span className="font-medium text-gray-900">
                  {product.seller.name}
                </span>
                <span>•</span>
                <span>★ {product.seller.rating}</span>
                <span>•</span>
                <span>{product.seller.totalSales} sales</span>
              </div>

              {/* Description */}
              <p className="mt-6 text-gray-600">{product.description}</p>

              {/* Quantity */}
              <div className="mt-6">
                <label className="block text-sm font-medium text-gray-900">
                  Quantity
                </label>
                <div className="mt-2 flex items-center gap-3">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="flex h-10 w-10 items-center justify-center rounded-lg border border-gray-300 bg-white text-gray-900 hover:bg-gray-50"
                  >
                    −
                  </button>
                  <span className="w-12 text-center text-lg font-medium">
                    {quantity}
                  </span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="flex h-10 w-10 items-center justify-center rounded-lg border border-gray-300 bg-white text-gray-900 hover:bg-gray-50"
                  >
                    +
                  </button>
                </div>
              </div>

              {/* CTA Buttons */}
              <div className="mt-8 space-y-3">
                <button
                  onClick={handleAddToCart}
                  className="w-full rounded-lg bg-gradient-to-r from-purple-600 to-pink-600 py-3 text-base font-medium text-white hover:from-purple-700 hover:to-pink-700"
                >
                  Add to Cart
                </button>
                <button
                  onClick={() => navigate("/checkout")}
                  className="w-full rounded-lg border border-gray-300 bg-white py-3 text-base font-medium text-gray-900 hover:bg-gray-50"
                >
                  Buy Now
                </button>
              </div>
            </div>

            {/* Trust Features */}
            <div className="mt-6 grid grid-cols-2 gap-4">
              {trustFeatures.map((feature, index) => (
                <div
                  key={index}
                  className="rounded-lg bg-white p-4 shadow-sm"
                >
                  <feature.icon className="h-6 w-6 text-purple-600" />
                  <h3 className="mt-2 text-sm font-medium text-gray-900">
                    {feature.title}
                  </h3>
                  <p className="mt-1 text-xs text-gray-600">
                    {feature.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
