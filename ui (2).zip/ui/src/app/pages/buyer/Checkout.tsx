import { Link, useNavigate } from "react-router";
import { Shield, Lock, CreditCard } from "lucide-react";
import { useState } from "react";

export default function Checkout() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    pincode: "",
  });

  const cartTotal = 4297;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    navigate("/order-success");
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="border-b bg-white">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8">
          <Link to="/" className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-r from-purple-600 to-pink-600">
              <span className="text-white font-bold">L</span>
            </div>
            <span className="text-xl font-bold text-gray-900">Loopy</span>
          </Link>
        </div>
      </header>

      <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8">
        {/* Trust Banner */}
        <div className="mb-6 flex flex-col sm:flex-row items-start sm:items-center gap-2 rounded-lg bg-purple-50 px-4 py-3 text-sm text-purple-700">
          <div className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            <span className="font-medium">Payment Protected:</span>
          </div>
          <span>Your money will be held securely until you receive your order</span>
        </div>

        <h1 className="mb-8 text-2xl font-bold text-gray-900">Checkout</h1>

        <div className="grid gap-8 lg:grid-cols-3">
          {/* Checkout Form */}
          <div className="lg:col-span-2">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Delivery Information */}
              <div className="rounded-xl bg-white p-6 shadow-sm">
                <h2 className="mb-4 text-lg font-semibold text-gray-900">
                  Delivery Information
                </h2>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-900">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) =>
                        setFormData({ ...formData, name: e.target.value })
                      }
                      className="mt-1 w-full rounded-lg border border-gray-300 bg-white px-4 py-2 text-gray-900 focus:border-purple-500 focus:outline-none focus:ring-1 focus:ring-purple-500"
                    />
                  </div>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div>
                      <label className="block text-sm font-medium text-gray-900">
                        Email *
                      </label>
                      <input
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) =>
                          setFormData({ ...formData, email: e.target.value })
                        }
                        className="mt-1 w-full rounded-lg border border-gray-300 bg-white px-4 py-2 text-gray-900 focus:border-purple-500 focus:outline-none focus:ring-1 focus:ring-purple-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-900">
                        Phone *
                      </label>
                      <input
                        type="tel"
                        required
                        value={formData.phone}
                        onChange={(e) =>
                          setFormData({ ...formData, phone: e.target.value })
                        }
                        className="mt-1 w-full rounded-lg border border-gray-300 bg-white px-4 py-2 text-gray-900 focus:border-purple-500 focus:outline-none focus:ring-1 focus:ring-purple-500"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-900">
                      Address *
                    </label>
                    <textarea
                      required
                      rows={3}
                      value={formData.address}
                      onChange={(e) =>
                        setFormData({ ...formData, address: e.target.value })
                      }
                      className="mt-1 w-full rounded-lg border border-gray-300 bg-white px-4 py-2 text-gray-900 focus:border-purple-500 focus:outline-none focus:ring-1 focus:ring-purple-500"
                    />
                  </div>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div>
                      <label className="block text-sm font-medium text-gray-900">
                        City *
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.city}
                        onChange={(e) =>
                          setFormData({ ...formData, city: e.target.value })
                        }
                        className="mt-1 w-full rounded-lg border border-gray-300 bg-white px-4 py-2 text-gray-900 focus:border-purple-500 focus:outline-none focus:ring-1 focus:ring-purple-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-900">
                        Pincode *
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.pincode}
                        onChange={(e) =>
                          setFormData({ ...formData, pincode: e.target.value })
                        }
                        className="mt-1 w-full rounded-lg border border-gray-300 bg-white px-4 py-2 text-gray-900 focus:border-purple-500 focus:outline-none focus:ring-1 focus:ring-purple-500"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Payment Method */}
              <div className="rounded-xl bg-white p-6 shadow-sm">
                <h2 className="mb-4 text-lg font-semibold text-gray-900">
                  Payment Method
                </h2>
                <div className="space-y-3">
                  <label className="flex items-start gap-3 rounded-lg border border-gray-300 p-4 cursor-pointer hover:border-purple-500">
                    <input
                      type="radio"
                      name="payment"
                      defaultChecked
                      className="mt-1"
                    />
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <CreditCard className="h-5 w-5 text-gray-600" />
                        <span className="font-medium text-gray-900">
                          Card / UPI / Netbanking
                        </span>
                      </div>
                      <p className="mt-1 text-sm text-gray-600">
                        Powered by Razorpay - Secure checkout
                      </p>
                    </div>
                  </label>
                  <label className="flex items-start gap-3 rounded-lg border border-gray-300 p-4 cursor-pointer hover:border-purple-500">
                    <input type="radio" name="payment" className="mt-1" />
                    <div className="flex-1">
                      <span className="font-medium text-gray-900">
                        Cash on Delivery
                      </span>
                      <p className="mt-1 text-sm text-gray-600">
                        Pay when you receive (Available in select areas)
                      </p>
                    </div>
                  </label>
                </div>
              </div>

              <button
                type="submit"
                className="w-full rounded-lg bg-gradient-to-r from-purple-600 to-pink-600 py-3 text-base font-medium text-white hover:from-purple-700 hover:to-pink-700"
              >
                <div className="flex items-center justify-center gap-2">
                  <Lock className="h-5 w-5" />
                  Complete Secure Payment
                </div>
              </button>
            </form>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="rounded-xl bg-white p-6 shadow-sm sticky top-8">
              <h2 className="text-lg font-semibold text-gray-900">
                Order Summary
              </h2>
              <div className="mt-4 space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Items (2)</span>
                  <span className="font-medium text-gray-900">
                    ₹{(cartTotal - 50).toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Delivery</span>
                  <span className="font-medium text-gray-900">₹50</span>
                </div>
                <div className="border-t pt-3">
                  <div className="flex justify-between">
                    <span className="font-semibold text-gray-900">Total</span>
                    <span className="text-xl font-bold text-gray-900">
                      ₹{cartTotal.toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>

              {/* Trust Indicators */}
              <div className="mt-6 space-y-3 border-t pt-6">
                <div className="flex items-start gap-2 text-sm">
                  <Shield className="h-5 w-5 flex-shrink-0 text-green-600" />
                  <div>
                    <p className="font-medium text-gray-900">
                      Payment Protection
                    </p>
                    <p className="text-xs text-gray-600">
                      Money held until delivery
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-2 text-sm">
                  <Lock className="h-5 w-5 flex-shrink-0 text-green-600" />
                  <div>
                    <p className="font-medium text-gray-900">Secure Checkout</p>
                    <p className="text-xs text-gray-600">
                      256-bit SSL encryption
                    </p>
                  </div>
                </div>
              </div>

              <div className="mt-6 rounded-lg bg-purple-50 p-4">
                <p className="text-xs text-purple-700">
                  <strong>Delivery Timeline:</strong> 3-5 business days
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
