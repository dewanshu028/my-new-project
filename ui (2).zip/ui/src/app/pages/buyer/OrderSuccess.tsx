import { Link } from "react-router";
import { CheckCircle, Package, Shield } from "lucide-react";

export default function OrderSuccess() {
  const orderId = "ORD-" + Math.random().toString(36).substr(2, 9).toUpperCase();

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="border-b bg-white">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8">
          <Link to="/" className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-r from-purple-600 to-pink-600">
              <span className="text-white font-bold">L</span>
            </div>
            <span className="text-xl font-bold text-gray-900">Loopy</span>
          </Link>
        </div>
      </header>

      <div className="mx-auto max-w-2xl px-4 py-16 sm:px-6 lg:px-8">
        {/* Success Icon */}
        <div className="text-center">
          <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-green-100">
            <CheckCircle className="h-12 w-12 text-green-600" />
          </div>

          <h1 className="mt-6 text-3xl font-bold text-gray-900">
            Order Confirmed!
          </h1>
          <p className="mt-2 text-lg text-gray-600">
            Thank you for your order
          </p>

          <div className="mt-8 rounded-xl bg-white p-6 shadow-sm">
            <div className="flex items-center justify-between border-b pb-4">
              <span className="text-sm text-gray-600">Order ID</span>
              <span className="font-mono font-medium text-gray-900">
                {orderId}
              </span>
            </div>
            <div className="flex items-center justify-between pt-4">
              <span className="text-sm text-gray-600">Total Amount</span>
              <span className="text-xl font-bold text-gray-900">
                ₹4,297
              </span>
            </div>
          </div>

          {/* Trust Message */}
          <div className="mt-6 rounded-lg bg-purple-50 p-6">
            <div className="flex items-start gap-3">
              <Shield className="h-6 w-6 flex-shrink-0 text-purple-600" />
              <div className="text-left">
                <h3 className="font-semibold text-purple-900">
                  Your payment is protected
                </h3>
                <p className="mt-1 text-sm text-purple-700">
                  Your money will be held securely and only released to the
                  seller after you confirm delivery. You can request a refund
                  anytime before delivery.
                </p>
              </div>
            </div>
          </div>

          {/* What's Next */}
          <div className="mt-8 rounded-xl bg-white p-6 shadow-sm text-left">
            <h2 className="flex items-center gap-2 font-semibold text-gray-900">
              <Package className="h-5 w-5 text-purple-600" />
              What happens next?
            </h2>
            <ol className="mt-4 space-y-4">
              <li className="flex gap-3">
                <span className="flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-full bg-purple-100 text-sm font-medium text-purple-600">
                  1
                </span>
                <div>
                  <p className="font-medium text-gray-900">
                    Seller prepares your order
                  </p>
                  <p className="text-sm text-gray-600">
                    Usually within 1-2 business days
                  </p>
                </div>
              </li>
              <li className="flex gap-3">
                <span className="flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-full bg-purple-100 text-sm font-medium text-purple-600">
                  2
                </span>
                <div>
                  <p className="font-medium text-gray-900">
                    Order is shipped
                  </p>
                  <p className="text-sm text-gray-600">
                    You'll receive tracking details via email & SMS
                  </p>
                </div>
              </li>
              <li className="flex gap-3">
                <span className="flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-full bg-purple-100 text-sm font-medium text-purple-600">
                  3
                </span>
                <div>
                  <p className="font-medium text-gray-900">
                    Delivery at your doorstep
                  </p>
                  <p className="text-sm text-gray-600">
                    Expected in 3-5 business days
                  </p>
                </div>
              </li>
            </ol>
          </div>

          {/* Action Buttons */}
          <div className="mt-8 flex flex-col gap-4 sm:flex-row sm:justify-center">
            <Link
              to={`/track-order/${orderId}`}
              className="inline-flex items-center justify-center rounded-lg bg-gradient-to-r from-purple-600 to-pink-600 px-8 py-3 text-base text-white hover:from-purple-700 hover:to-pink-700"
            >
              Track Your Order
            </Link>
            <Link
              to="/shop"
              className="inline-flex items-center justify-center rounded-lg border border-gray-300 bg-white px-8 py-3 text-base text-gray-900 hover:bg-gray-50"
            >
              Continue Shopping
            </Link>
          </div>

          <p className="mt-8 text-sm text-gray-500">
            We've sent a confirmation email to your registered email address
          </p>
        </div>
      </div>
    </div>
  );
}
