import { Link } from "react-router";
import { Shield, TrendingUp, Package, CheckCircle } from "lucide-react";
import { ImageWithFallback } from "../../components/figma/ImageWithFallback";

export default function LandingPage() {
  const features = [
    {
      icon: Shield,
      title: "100% Payment Protection",
      description: "Your money is held safely until you receive your order",
    },
    {
      icon: CheckCircle,
      title: "Verified Sellers",
      description: "All sellers are verified through our KYC process",
    },
    {
      icon: Package,
      title: "Easy Returns",
      description: "Hassle-free returns and refunds if something goes wrong",
    },
    {
      icon: TrendingUp,
      title: "Best Deals",
      description: "Direct from Instagram & WhatsApp sellers",
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="border-b">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-r from-purple-600 to-pink-600">
                <span className="text-white font-bold">L</span>
              </div>
              <span className="text-xl font-bold text-gray-900">Loopy</span>
            </Link>
            <nav className="flex items-center gap-4">
              <Link
                to="/seller/dashboard"
                className="text-sm text-gray-600 hover:text-gray-900"
              >
                Sell on Loopy
              </Link>
              <Link
                to="/cart"
                className="rounded-lg bg-gray-900 px-4 py-2 text-sm text-white hover:bg-gray-800"
              >
                Cart
              </Link>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid gap-12 lg:grid-cols-2 lg:gap-16">
          <div className="flex flex-col justify-center">
            <div className="inline-flex items-center gap-2 rounded-full bg-purple-50 px-4 py-2 text-sm text-purple-700 w-fit mb-6">
              <Shield className="h-4 w-4" />
              Trusted by 50,000+ shoppers
            </div>
            <h1 className="text-4xl font-bold tracking-tight text-gray-900 sm:text-5xl lg:text-6xl">
              Shop safely from your favorite Instagram sellers
            </h1>
            <p className="mt-6 text-lg text-gray-600">
              Loopy protects your payments until delivery. Buy with confidence
              from verified sellers on Instagram and WhatsApp.
            </p>
            <div className="mt-8 flex flex-col gap-4 sm:flex-row">
              <Link
                to="/shop"
                className="inline-flex items-center justify-center rounded-lg bg-gradient-to-r from-purple-600 to-pink-600 px-8 py-3 text-base text-white hover:from-purple-700 hover:to-pink-700"
              >
                Start Shopping
              </Link>
              <Link
                to="/seller/dashboard"
                className="inline-flex items-center justify-center rounded-lg border border-gray-300 bg-white px-8 py-3 text-base text-gray-900 hover:bg-gray-50"
              >
                Become a Seller
              </Link>
            </div>
          </div>
          <div className="relative">
            <div className="aspect-square overflow-hidden rounded-2xl bg-gray-100">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1605902711622-cfb43c4437b5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzbWFydHBob25lJTIwb25saW5lJTIwc2hvcHBpbmd8ZW58MXx8fHwxNzgxNTM2NDM1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Shopping on mobile"
                className="h-full w-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="bg-gray-50 py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900">
              Why shop with Loopy?
            </h2>
            <p className="mt-4 text-lg text-gray-600">
              The safest way to buy from social media sellers
            </p>
          </div>
          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {features.map((feature, index) => (
              <div
                key={index}
                className="rounded-xl bg-white p-6 shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-purple-100">
                  <feature.icon className="h-6 w-6 text-purple-600" />
                </div>
                <h3 className="mt-4 text-lg font-semibold text-gray-900">
                  {feature.title}
                </h3>
                <p className="mt-2 text-sm text-gray-600">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="rounded-2xl bg-gradient-to-r from-purple-600 to-pink-600 px-8 py-12 text-center">
            <h2 className="text-3xl font-bold text-white">
              Ready to start shopping?
            </h2>
            <p className="mt-4 text-lg text-purple-100">
              Join thousands of happy customers buying safely from social sellers
            </p>
            <Link
              to="/shop"
              className="mt-8 inline-flex items-center justify-center rounded-lg bg-white px-8 py-3 text-base text-purple-600 hover:bg-gray-50"
            >
              Browse Products
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t bg-gray-50 py-12">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center text-sm text-gray-600">
            <p>© 2026 Loopy. All rights reserved.</p>
            <div className="mt-4 flex justify-center gap-6">
              <a href="#" className="hover:text-gray-900">Terms</a>
              <a href="#" className="hover:text-gray-900">Privacy</a>
              <a href="#" className="hover:text-gray-900">Support</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
