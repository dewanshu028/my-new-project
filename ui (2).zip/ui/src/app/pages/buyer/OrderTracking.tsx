import { Link, useParams } from "react-router";
import { Package, Truck, CheckCircle, MapPin, Phone, Shield } from "lucide-react";

export default function OrderTracking() {
  const { orderId } = useParams();

  const orderStatus = [
    {
      status: "Order Confirmed",
      date: "June 15, 2026",
      time: "10:30 AM",
      completed: true,
    },
    {
      status: "Order Packed",
      date: "June 15, 2026",
      time: "3:45 PM",
      completed: true,
    },
    {
      status: "Shipped",
      date: "June 16, 2026",
      time: "9:00 AM",
      completed: true,
    },
    {
      status: "Out for Delivery",
      date: "June 18, 2026",
      time: "Expected",
      completed: false,
    },
    {
      status: "Delivered",
      date: "Estimated",
      time: "June 18, 2026",
      completed: false,
    },
  ];

  const currentStep = 2;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="border-b bg-white">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8">
          <Link to="/" className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-r from-purple-600 to-pink-600">
              <span className="text-white font-bold">L</span>
            </div>
            <span className="text-xl font-bold text-gray-900">Loopy</span>
          </Link>
        </div>
      </header>

      <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8">
        {/* Order Info */}
        <div className="mb-6 rounded-xl bg-white p-6 shadow-sm">
          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">
                Track Your Order
              </h1>
              <p className="mt-1 text-sm text-gray-600">
                Order ID:{" "}
                <span className="font-mono font-medium text-gray-900">
                  {orderId}
                </span>
              </p>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-600">Expected Delivery</p>
              <p className="font-semibold text-gray-900">June 18, 2026</p>
            </div>
          </div>
        </div>

        {/* Trust Banner */}
        <div className="mb-6 flex items-start gap-2 rounded-lg bg-purple-50 px-4 py-3 text-sm text-purple-700">
          <Shield className="h-5 w-5 mt-0.5 flex-shrink-0" />
          <div>
            <span className="font-medium">Payment is protected:</span>{" "}
            <span>
              Your payment will be released to the seller only after you confirm
              delivery
            </span>
          </div>
        </div>

        {/* Tracking Timeline */}
        <div className="rounded-xl bg-white p-6 shadow-sm">
          <h2 className="mb-6 text-lg font-semibold text-gray-900">
            Order Status
          </h2>
          <div className="space-y-6">
            {orderStatus.map((step, index) => (
              <div key={index} className="relative flex gap-4">
                {/* Timeline Line */}
                {index < orderStatus.length - 1 && (
                  <div
                    className={`absolute left-4 top-10 h-full w-0.5 ${
                      index < currentStep ? "bg-purple-600" : "bg-gray-200"
                    }`}
                  />
                )}

                {/* Status Icon */}
                <div className="relative z-10 flex-shrink-0">
                  <div
                    className={`flex h-8 w-8 items-center justify-center rounded-full ${
                      step.completed
                        ? "bg-purple-600"
                        : index === currentStep
                        ? "bg-purple-600 ring-4 ring-purple-100"
                        : "bg-gray-200"
                    }`}
                  >
                    {step.completed ? (
                      <CheckCircle className="h-5 w-5 text-white" />
                    ) : index === currentStep ? (
                      <Truck className="h-5 w-5 text-white" />
                    ) : (
                      <Package className="h-5 w-5 text-gray-400" />
                    )}
                  </div>
                </div>

                {/* Status Info */}
                <div className="flex-1 pb-8">
                  <h3
                    className={`font-semibold ${
                      step.completed || index === currentStep
                        ? "text-gray-900"
                        : "text-gray-500"
                    }`}
                  >
                    {step.status}
                  </h3>
                  <p className="mt-1 text-sm text-gray-600">
                    {step.date}{" "}
                    {step.time && (
                      <span className="text-gray-500">• {step.time}</span>
                    )}
                  </p>
                  {index === currentStep && (
                    <p className="mt-2 inline-flex items-center gap-1 text-sm font-medium text-purple-600">
                      <Truck className="h-4 w-4" />
                      In Transit
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Delivery Address */}
        <div className="mt-6 rounded-xl bg-white p-6 shadow-sm">
          <h2 className="mb-4 flex items-center gap-2 text-lg font-semibold text-gray-900">
            <MapPin className="h-5 w-5 text-purple-600" />
            Delivery Address
          </h2>
          <p className="text-gray-900">John Doe</p>
          <p className="mt-1 text-sm text-gray-600">
            123, Main Street, Apartment 4B
            <br />
            Mumbai, Maharashtra - 400001
            <br />
            India
          </p>
        </div>

        {/* Seller & Support */}
        <div className="mt-6 grid gap-6 sm:grid-cols-2">
          <div className="rounded-xl bg-white p-6 shadow-sm">
            <h2 className="mb-4 text-lg font-semibold text-gray-900">
              Seller Information
            </h2>
            <p className="font-medium text-gray-900">Artisan Jewelry Co.</p>
            <div className="mt-3 inline-flex items-center gap-2 rounded-full bg-green-50 px-3 py-1 text-sm text-green-700">
              <CheckCircle className="h-4 w-4" />
              Verified Seller
            </div>
          </div>

          <div className="rounded-xl bg-white p-6 shadow-sm">
            <h2 className="mb-4 text-lg font-semibold text-gray-900">
              Need Help?
            </h2>
            <button className="flex items-center gap-2 text-purple-600 hover:text-purple-700">
              <Phone className="h-4 w-4" />
              Contact Support
            </button>
            <button className="mt-3 flex items-center gap-2 text-purple-600 hover:text-purple-700">
              <Shield className="h-4 w-4" />
              Report an Issue
            </button>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="mt-8 flex flex-col gap-4 sm:flex-row">
          <Link
            to="/shop"
            className="flex-1 rounded-lg border border-gray-300 bg-white py-3 text-center text-base font-medium text-gray-900 hover:bg-gray-50"
          >
            Continue Shopping
          </Link>
          <button className="flex-1 rounded-lg bg-gradient-to-r from-purple-600 to-pink-600 py-3 text-base font-medium text-white hover:from-purple-700 hover:to-pink-700">
            Confirm Delivery (Once Received)
          </button>
        </div>
      </div>
    </div>
  );
}
