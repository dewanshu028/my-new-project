import { Link } from "react-router";
import { CheckCircle, XCircle, FileText, User } from "lucide-react";
import { ImageWithFallback } from "../../components/figma/ImageWithFallback";

export default function AdminKYC() {
  const kycApplications = [
    {
      id: "KYC-001",
      sellerName: "Artisan Jewelry Co.",
      email: "artisan@example.com",
      phone: "+91 98765 43210",
      businessType: "Individual",
      documents: ["Aadhaar Card", "PAN Card", "Bank Statement"],
      submittedDate: "June 14, 2026",
      status: "Pending",
      image: "https://images.unsplash.com/photo-1780332693380-7a8957a321d0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx5b3VuZyUyMHdvbWFuJTIwc2VsbGVyJTIwZW50cmVwcmVuZXVyfGVufDF8fHx8MTc4MTUzNjQzNXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    },
    {
      id: "KYC-002",
      sellerName: "Fashion Forward",
      email: "fashion@example.com",
      phone: "+91 98765 43211",
      businessType: "Company",
      documents: ["GST Certificate", "Company Registration", "Bank Details"],
      submittedDate: "June 13, 2026",
      status: "Pending",
      image: "https://images.unsplash.com/photo-1780332693380-7a8957a321d0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx5b3VuZyUyMHdvbWFuJTIwc2VsbGVyJTIwZW50cmVwcmVuZXVyfGVufDF8fHx8MTc4MTUzNjQzNXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    },
    {
      id: "KYC-003",
      sellerName: "Beauty by Sarah",
      email: "sarah@example.com",
      phone: "+91 98765 43212",
      businessType: "Individual",
      documents: ["Aadhaar Card", "PAN Card"],
      submittedDate: "June 12, 2026",
      status: "Approved",
      image: "https://images.unsplash.com/photo-1780332693380-7a8957a321d0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx5b3VuZyUyMHdvbWFuJTIwc2VsbGVyJTIwZW50cmVwcmVuZXVyfGVufDF8fHx8MTc4MTUzNjQzNXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="border-b bg-white sticky top-0 z-10">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-r from-purple-600 to-pink-600">
                <span className="text-white font-bold">L</span>
              </div>
              <span className="text-xl font-bold text-gray-900">Loopy</span>
              <span className="ml-2 text-sm text-gray-600">Admin</span>
            </Link>
            <nav className="flex items-center gap-4">
              <Link
                to="/admin/orders"
                className="text-sm text-gray-600 hover:text-gray-900"
              >
                Orders
              </Link>
            </nav>
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        {/* Page Header */}
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900">KYC Management</h1>
          <p className="mt-1 text-sm text-gray-600">
            Review and approve seller verification requests
          </p>
        </div>

        {/* Stats */}
        <div className="mb-8 grid gap-6 sm:grid-cols-3">
          <div className="rounded-xl bg-white p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Pending Review</p>
                <p className="mt-2 text-3xl font-bold text-gray-900">2</p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-yellow-100">
                <FileText className="h-6 w-6 text-yellow-600" />
              </div>
            </div>
          </div>

          <div className="rounded-xl bg-white p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Approved</p>
                <p className="mt-2 text-3xl font-bold text-gray-900">28</p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-green-100">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </div>

          <div className="rounded-xl bg-white p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Rejected</p>
                <p className="mt-2 text-3xl font-bold text-gray-900">5</p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-red-100">
                <XCircle className="h-6 w-6 text-red-600" />
              </div>
            </div>
          </div>
        </div>

        {/* KYC Applications */}
        <div className="space-y-6">
          {kycApplications.map((application) => (
            <div
              key={application.id}
              className="rounded-xl bg-white p-6 shadow-sm"
            >
              <div className="flex flex-col gap-6 lg:flex-row lg:items-start lg:justify-between">
                {/* Application Info */}
                <div className="flex flex-1 gap-4">
                  <div className="h-16 w-16 flex-shrink-0 overflow-hidden rounded-lg bg-gray-100">
                    <ImageWithFallback
                      src={application.image}
                      alt={application.sellerName}
                      className="h-full w-full object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="font-semibold text-gray-900">
                          {application.sellerName}
                        </h3>
                        <p className="mt-1 text-sm text-gray-600">
                          {application.email}
                        </p>
                        <p className="text-sm text-gray-600">
                          {application.phone}
                        </p>
                      </div>
                      <span
                        className={`inline-flex rounded-full px-3 py-1 text-xs font-medium ${
                          application.status === "Pending"
                            ? "bg-yellow-100 text-yellow-800"
                            : application.status === "Approved"
                            ? "bg-green-100 text-green-800"
                            : "bg-red-100 text-red-800"
                        }`}
                      >
                        {application.status}
                      </span>
                    </div>

                    <div className="mt-4 grid gap-4 sm:grid-cols-2">
                      <div>
                        <p className="text-xs text-gray-500">Application ID</p>
                        <p className="mt-1 font-mono text-sm text-gray-900">
                          {application.id}
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-500">Business Type</p>
                        <p className="mt-1 text-sm text-gray-900">
                          {application.businessType}
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-500">Submitted Date</p>
                        <p className="mt-1 text-sm text-gray-900">
                          {application.submittedDate}
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-500">Documents</p>
                        <div className="mt-1 flex flex-wrap gap-1">
                          {application.documents.map((doc, index) => (
                            <span
                              key={index}
                              className="inline-flex items-center gap-1 rounded bg-gray-100 px-2 py-1 text-xs text-gray-700"
                            >
                              <FileText className="h-3 w-3" />
                              {doc}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Actions */}
                {application.status === "Pending" && (
                  <div className="flex gap-3 lg:flex-col">
                    <button className="flex flex-1 items-center justify-center gap-2 rounded-lg bg-green-600 px-6 py-2 text-sm font-medium text-white hover:bg-green-700 lg:flex-initial">
                      <CheckCircle className="h-4 w-4" />
                      Approve
                    </button>
                    <button className="flex flex-1 items-center justify-center gap-2 rounded-lg border border-red-300 bg-white px-6 py-2 text-sm font-medium text-red-600 hover:bg-red-50 lg:flex-initial">
                      <XCircle className="h-4 w-4" />
                      Reject
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
