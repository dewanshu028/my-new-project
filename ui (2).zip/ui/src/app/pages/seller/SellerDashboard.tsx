import { Link } from "react-router";
import { Package, DollarSign, ShoppingBag, TrendingUp, Plus } from "lucide-react";

export default function SellerDashboard() {
  const stats = [
    {
      label: "Total Orders",
      value: "48",
      change: "+12% from last month",
      icon: ShoppingBag,
      color: "bg-blue-100 text-blue-600",
    },
    {
      label: "Total Revenue",
      value: "₹1,24,580",
      change: "+23% from last month",
      icon: DollarSign,
      color: "bg-green-100 text-green-600",
    },
    {
      label: "Active Products",
      value: "15",
      change: "2 pending approval",
      icon: Package,
      color: "bg-purple-100 text-purple-600",
    },
    {
      label: "Growth",
      value: "+45%",
      change: "This month",
      icon: TrendingUp,
      color: "bg-orange-100 text-orange-600",
    },
  ];

  const recentOrders = [
    {
      id: "ORD-A1B2C3",
      customer: "Priya Sharma",
      product: "Silver Necklace",
      amount: 2499,
      status: "Pending",
      date: "June 15, 2026",
    },
    {
      id: "ORD-D4E5F6",
      customer: "Rahul Patel",
      product: "Gold Earrings",
      amount: 3499,
      status: "Shipped",
      date: "June 14, 2026",
    },
    {
      id: "ORD-G7H8I9",
      customer: "Anjali Desai",
      product: "Silver Bracelet",
      amount: 1899,
      status: "Delivered",
      date: "June 13, 2026",
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="border-b bg-white sticky top-0 z-10">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-r from-purple-600 to-pink-600">
                <span className="text-white font-bold">L</span>
              </div>
              <span className="text-xl font-bold text-gray-900">Loopy</span>
              <span className="ml-2 text-sm text-gray-600">Seller</span>
            </Link>
            <nav className="flex items-center gap-4">
              <Link
                to="/seller/orders"
                className="text-sm text-gray-600 hover:text-gray-900"
              >
                Orders
              </Link>
              <Link
                to="/seller/wallet"
                className="text-sm text-gray-600 hover:text-gray-900"
              >
                Wallet
              </Link>
              <Link
                to="/"
                className="text-sm text-gray-600 hover:text-gray-900"
              >
                Store
              </Link>
            </nav>
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        {/* Page Header */}
        <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
            <p className="mt-1 text-sm text-gray-600">
              Welcome back, Artisan Jewelry Co.
            </p>
          </div>
          <Link
            to="/seller/add-product"
            className="inline-flex items-center justify-center gap-2 rounded-lg bg-gradient-to-r from-purple-600 to-pink-600 px-6 py-3 text-base text-white hover:from-purple-700 hover:to-pink-700"
          >
            <Plus className="h-5 w-5" />
            Add Product
          </Link>
        </div>

        {/* Stats Grid */}
        <div className="mb-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {stats.map((stat, index) => (
            <div key={index} className="rounded-xl bg-white p-6 shadow-sm">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">{stat.label}</p>
                  <p className="mt-2 text-2xl font-bold text-gray-900">
                    {stat.value}
                  </p>
                  <p className="mt-1 text-xs text-gray-500">{stat.change}</p>
                </div>
                <div className={`flex h-12 w-12 items-center justify-center rounded-lg ${stat.color}`}>
                  <stat.icon className="h-6 w-6" />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Recent Orders */}
        <div className="rounded-xl bg-white shadow-sm">
          <div className="flex items-center justify-between border-b px-6 py-4">
            <h2 className="text-lg font-semibold text-gray-900">
              Recent Orders
            </h2>
            <Link
              to="/seller/orders"
              className="text-sm text-purple-600 hover:text-purple-700"
            >
              View all
            </Link>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                    Order ID
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                    Customer
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                    Product
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                    Amount
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                    Date
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200 bg-white">
                {recentOrders.map((order) => (
                  <tr key={order.id} className="hover:bg-gray-50">
                    <td className="whitespace-nowrap px-6 py-4 text-sm font-mono font-medium text-gray-900">
                      {order.id}
                    </td>
                    <td className="whitespace-nowrap px-6 py-4 text-sm text-gray-900">
                      {order.customer}
                    </td>
                    <td className="whitespace-nowrap px-6 py-4 text-sm text-gray-600">
                      {order.product}
                    </td>
                    <td className="whitespace-nowrap px-6 py-4 text-sm font-medium text-gray-900">
                      ₹{order.amount.toLocaleString()}
                    </td>
                    <td className="whitespace-nowrap px-6 py-4">
                      <span
                        className={`inline-flex rounded-full px-2 py-1 text-xs font-medium ${
                          order.status === "Pending"
                            ? "bg-yellow-100 text-yellow-800"
                            : order.status === "Shipped"
                            ? "bg-blue-100 text-blue-800"
                            : "bg-green-100 text-green-800"
                        }`}
                      >
                        {order.status}
                      </span>
                    </td>
                    <td className="whitespace-nowrap px-6 py-4 text-sm text-gray-600">
                      {order.date}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
