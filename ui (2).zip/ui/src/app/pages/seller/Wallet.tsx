import { Link } from "react-router";
import { DollarSign, TrendingUp, Clock, CheckCircle, ArrowDownToLine } from "lucide-react";

export default function Wallet() {
  const transactions = [
    {
      id: "TXN-001",
      orderId: "ORD-G7H8I9",
      amount: 1899,
      status: "Completed",
      date: "June 13, 2026",
      type: "Sale",
    },
    {
      id: "TXN-002",
      orderId: "ORD-D4E5F6",
      amount: 3499,
      status: "Processing",
      date: "June 14, 2026",
      type: "Sale",
    },
    {
      id: "TXN-003",
      orderId: "-",
      amount: -5000,
      status: "Completed",
      date: "June 10, 2026",
      type: "Withdrawal",
    },
  ];

  const stats = {
    availableBalance: 24580,
    pendingBalance: 5998,
    totalEarnings: 124580,
    thisMonth: 30578,
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="border-b bg-white sticky top-0 z-10">
        <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-r from-purple-600 to-pink-600">
                <span className="text-white font-bold">L</span>
              </div>
              <span className="text-xl font-bold text-gray-900">Loopy</span>
              <span className="ml-2 text-sm text-gray-600">Seller</span>
            </Link>
            <nav className="flex items-center gap-4">
              <Link
                to="/seller/dashboard"
                className="text-sm text-gray-600 hover:text-gray-900"
              >
                Dashboard
              </Link>
              <Link
                to="/seller/orders"
                className="text-sm text-gray-600 hover:text-gray-900"
              >
                Orders
              </Link>
            </nav>
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        {/* Page Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Wallet & Earnings</h1>
          <p className="mt-1 text-sm text-gray-600">
            Track your earnings and manage withdrawals
          </p>
        </div>

        {/* Balance Cards */}
        <div className="mb-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          <div className="rounded-xl bg-gradient-to-br from-purple-600 to-pink-600 p-6 text-white shadow-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm opacity-90">Available Balance</p>
                <p className="mt-2 text-3xl font-bold">
                  ₹{stats.availableBalance.toLocaleString()}
                </p>
              </div>
              <DollarSign className="h-10 w-10 opacity-80" />
            </div>
            <button className="mt-4 flex w-full items-center justify-center gap-2 rounded-lg bg-white/20 py-2 text-sm font-medium hover:bg-white/30 transition-colors">
              <ArrowDownToLine className="h-4 w-4" />
              Withdraw
            </button>
          </div>

          <div className="rounded-xl bg-white p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Pending Balance</p>
                <p className="mt-2 text-2xl font-bold text-gray-900">
                  ₹{stats.pendingBalance.toLocaleString()}
                </p>
              </div>
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-yellow-100">
                <Clock className="h-6 w-6 text-yellow-600" />
              </div>
            </div>
            <p className="mt-2 text-xs text-gray-500">
              Will be available after delivery
            </p>
          </div>

          <div className="rounded-xl bg-white p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Earnings</p>
                <p className="mt-2 text-2xl font-bold text-gray-900">
                  ₹{stats.totalEarnings.toLocaleString()}
                </p>
              </div>
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-green-100">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
            </div>
            <p className="mt-2 text-xs text-gray-500">
              All-time earnings
            </p>
          </div>

          <div className="rounded-xl bg-white p-6 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">This Month</p>
                <p className="mt-2 text-2xl font-bold text-gray-900">
                  ₹{stats.thisMonth.toLocaleString()}
                </p>
              </div>
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-100">
                <TrendingUp className="h-6 w-6 text-blue-600" />
              </div>
            </div>
            <p className="mt-2 text-xs text-green-600">
              +23% from last month
            </p>
          </div>
        </div>

        {/* Transaction History */}
        <div className="rounded-xl bg-white shadow-sm">
          <div className="border-b px-6 py-4">
            <h2 className="text-lg font-semibold text-gray-900">
              Transaction History
            </h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                    Transaction ID
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                    Order ID
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                    Type
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                    Amount
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider text-gray-500">
                    Date
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200 bg-white">
                {transactions.map((transaction) => (
                  <tr key={transaction.id} className="hover:bg-gray-50">
                    <td className="whitespace-nowrap px-6 py-4 text-sm font-mono font-medium text-gray-900">
                      {transaction.id}
                    </td>
                    <td className="whitespace-nowrap px-6 py-4 text-sm font-mono text-gray-600">
                      {transaction.orderId}
                    </td>
                    <td className="whitespace-nowrap px-6 py-4 text-sm text-gray-900">
                      {transaction.type}
                    </td>
                    <td className="whitespace-nowrap px-6 py-4 text-sm font-semibold">
                      <span
                        className={
                          transaction.amount > 0
                            ? "text-green-600"
                            : "text-red-600"
                        }
                      >
                        {transaction.amount > 0 ? "+" : ""}₹
                        {Math.abs(transaction.amount).toLocaleString()}
                      </span>
                    </td>
                    <td className="whitespace-nowrap px-6 py-4">
                      <span
                        className={`inline-flex rounded-full px-2 py-1 text-xs font-medium ${
                          transaction.status === "Completed"
                            ? "bg-green-100 text-green-800"
                            : "bg-yellow-100 text-yellow-800"
                        }`}
                      >
                        {transaction.status}
                      </span>
                    </td>
                    <td className="whitespace-nowrap px-6 py-4 text-sm text-gray-600">
                      {transaction.date}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Withdrawal Info */}
        <div className="mt-6 rounded-lg bg-blue-50 p-4">
          <p className="text-sm text-blue-900">
            <strong>Note:</strong> Withdrawals are processed within 2-3 business
            days. Minimum withdrawal amount is ₹500. Platform fee of 5% + ₹10 per
            transaction is automatically deducted.
          </p>
        </div>
      </div>
    </div>
  );
}
