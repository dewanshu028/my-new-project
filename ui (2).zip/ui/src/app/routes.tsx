import { createBrowserRouter } from "react-router";
import LandingPage from "./pages/buyer/LandingPage";
import ProductListing from "./pages/buyer/ProductListing";
import ProductPage from "./pages/buyer/ProductPage";
import Cart from "./pages/buyer/Cart";
import Checkout from "./pages/buyer/Checkout";
import OrderSuccess from "./pages/buyer/OrderSuccess";
import OrderTracking from "./pages/buyer/OrderTracking";
import SellerDashboard from "./pages/seller/SellerDashboard";
import AddProduct from "./pages/seller/AddProduct";
import SellerOrders from "./pages/seller/SellerOrders";
import Wallet from "./pages/seller/Wallet";
import AdminKYC from "./pages/admin/AdminKYC";
import AdminOrders from "./pages/admin/AdminOrders";
import NotFound from "./pages/NotFound";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: LandingPage,
  },
  {
    path: "/shop",
    Component: ProductListing,
  },
  {
    path: "/product/:id",
    Component: ProductPage,
  },
  {
    path: "/cart",
    Component: Cart,
  },
  {
    path: "/checkout",
    Component: Checkout,
  },
  {
    path: "/order-success",
    Component: OrderSuccess,
  },
  {
    path: "/track-order/:orderId",
    Component: OrderTracking,
  },
  {
    path: "/seller/dashboard",
    Component: SellerDashboard,
  },
  {
    path: "/seller/add-product",
    Component: AddProduct,
  },
  {
    path: "/seller/orders",
    Component: SellerOrders,
  },
  {
    path: "/seller/wallet",
    Component: Wallet,
  },
  {
    path: "/admin/kyc",
    Component: AdminKYC,
  },
  {
    path: "/admin/orders",
    Component: AdminOrders,
  },
  {
    path: "*",
    Component: NotFound,
  },
]);
