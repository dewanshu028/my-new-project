
  # Create UI Design

  This is a code bundle for Create UI Design. The original project is available at https://www.figma.com/design/lijNXE1MeQgDdpPtAsbs5k/Create-UI-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  